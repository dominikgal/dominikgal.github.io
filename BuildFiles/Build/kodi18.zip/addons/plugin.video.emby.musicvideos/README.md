# plugin.video.emby.musicvideos
plugin.video.emby dependency for music videos
