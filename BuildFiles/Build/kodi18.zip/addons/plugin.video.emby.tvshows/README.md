# plugin.video.emby.tvshows
plugin.video.emby dependency for tv shows
