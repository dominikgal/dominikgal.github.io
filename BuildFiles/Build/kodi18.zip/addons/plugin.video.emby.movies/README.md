# plugin.video.emby.movies
plugin.video.emby dependency for movies
